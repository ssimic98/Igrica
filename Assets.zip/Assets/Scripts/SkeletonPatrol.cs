using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkeletonPatrol : MonoBehaviour
{
    public Transform pointA;
    public Transform pointB;
    public Transform skeleton;
    public  Animator animate;
    private Vector3 initiateScale;
    public float speed;
    private bool isRight;
    void Start()
    {
        initiateScale=skeleton.localScale;
    }
    void Update()
     {
        if(skeleton!=null)
        {
            if(isRight)
            {
                if(skeleton.position.x <=pointB.position.x)
                {
                    MoveInDirection(1);
                }
                else
                {
                    ChangeDirection();
                }
            
            }
            else
            {
                if(skeleton.position.x>=pointA.position.x)
                {
                    MoveInDirection(-1);
                }
                else
                {
                    ChangeDirection();
                }
            
            }
        }
        
        
     }
     private void ChangeDirection()
     {
        animate.SetBool("isWalking",false);
        isRight=!isRight;
     }

    private void MoveInDirection(int directon)
    {
        animate.SetBool("isWalking",true);
        skeleton.localScale=new Vector3(Mathf.Abs(initiateScale.x)*directon,initiateScale.y,initiateScale.z);
        skeleton.position=new Vector3(skeleton.position.x+Time.deltaTime*directon,skeleton.position.y,skeleton.position.z);
    }
}

