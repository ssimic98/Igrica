using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{

    public float bulletSpeed;
    public float bulletResetTime;
    private Animator animate;
    private BoxCollider2D boxCollider;
    private bool isHit;
    private float bulletDirection;
    private float bulletLifetime;
    private void Awake()
    {
        animate = GetComponent<Animator>();
        boxCollider = GetComponent<BoxCollider2D>();
    }
    private void Update()
    {
        if (isHit) return;
        float movementSpeed = bulletSpeed * Time.deltaTime * bulletDirection;
        transform.Translate(movementSpeed, 0, 0);

    //Time that needs to pass for the bullet to be destroyed
        bulletLifetime += Time.deltaTime;
        if (bulletLifetime > bulletResetTime) gameObject.SetActive(false);
    }
    private void OnTriggerEnter2D(Collider2D collider)
    {
        isHit = true;
        boxCollider.enabled = false;
        animate.SetTrigger("explode");
        if(collider.gameObject.tag == "Enemy")
        {
            Destroy(collider.gameObject);
            animate.SetTrigger("explode");
        }
    }
    public void SetDirection(float _bulletDirection)
    {
        bulletLifetime = 0;
        bulletDirection = _bulletDirection;
        gameObject.SetActive(true);
        isHit = false;
        boxCollider.enabled = true;

        float localScaleX = transform.localScale.x;
        if (Mathf.Sign(localScaleX) != _bulletDirection)
        {
            localScaleX = -localScaleX;
        }  

        transform.localScale = new Vector3(localScaleX, transform.localScale.y, transform.localScale.z);
    }
    private void Deactivate()
    {
        gameObject.SetActive(false);
    }
}

