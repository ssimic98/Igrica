using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlyPatrol : MonoBehaviour
{
    public float speed;
    public float range;

    float startingY;
    int directon=1;
    void Start()
    {
        startingY=transform.position.y;
    }
    void Update()
    {
        transform.Translate(Vector2.up*speed*Time.deltaTime*directon);
        if(transform.position.y < startingY || transform.position.y > startingY + range)
        {
            directon*=-1;
        }
    }
}

