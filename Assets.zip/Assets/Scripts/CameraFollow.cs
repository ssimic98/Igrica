using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public float FollowSpeed = 2f;
    public Vector3 minValue,maxValue;
    public Transform target;


    // Update is called once per frame
    void Update()
    {
        Camera();
    }
    void Camera()
    {
        //Camera boundries and following player
        Vector3 targetPositon=target.position;
        
        Vector3 boundPosition=new Vector3(Mathf.Clamp(target.position.x,minValue.x,maxValue.x),
        Mathf.Clamp(target.position.y,minValue.y,maxValue.y),
        Mathf.Clamp(target.position.z,minValue.z,maxValue.z));

        Vector3 newPosition=Vector3.Lerp(transform.position, boundPosition,FollowSpeed*Time.deltaTime);
        transform.position=newPosition;
    }
}

