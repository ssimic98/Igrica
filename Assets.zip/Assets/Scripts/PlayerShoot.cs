using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShoot : MonoBehaviour
{
    // Start is called before the first frame update
    private Animator animate;
    private Movement movement;
    private float coolDownTimer=Mathf.Infinity;
    public float attackCooldown;
    //Empty Game object where we are going to put bullet in front of the player
    public Transform bulletPosition;
    public GameObject[] bullets;
    void Awake()
    { 
        animate=GetComponent<Animator>();
        movement=GetComponent<Movement>();
    }  

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && coolDownTimer > attackCooldown && movement.canShoot())
        {
            Shoot();
        }
        coolDownTimer += Time.deltaTime;  
    }
    public void Shoot()
    {
        animate.SetTrigger("shoot");
        coolDownTimer=0;
        bullets[FindBullet()].transform.position = bulletPosition.position;
        bullets[FindBullet()].GetComponent<Bullet>().SetDirection(Mathf.Sign(transform.localScale.x));
    }
    private int FindBullet()
    {
        for (int i = 0; i < bullets.Length; i++)
        {
            if (!bullets[i].activeInHierarchy)
                return i;
        }
        return 0;
    }
    
}
