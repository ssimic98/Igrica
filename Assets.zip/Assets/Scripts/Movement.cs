using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    private Rigidbody2D body;
    private Animator animate;
    public  float jumpForce;
    public float speed;
    // Start is called before the first frame update
    private float horizontalInput;
    private bool isRight=true;
    private bool Ground;
    private void Awake()
    {
        body=GetComponent<Rigidbody2D>();
        animate=GetComponent<Animator>();
    }

    // Update is called once per frame
    private void Update()
    {
        horizontalInput=Input.GetAxis("Horizontal");
        body.velocity=new Vector2(Input.GetAxis("Horizontal")*speed , body.velocity.y);
        if(Input.GetKey(KeyCode.UpArrow) && Ground)
        {
            Jumping();
        }

        if(horizontalInput > 0 && !isRight)
        {
            FlipPlayer();
        }
        if(horizontalInput < 0 && isRight)
        {
            FlipPlayer();
        }
        animate.SetBool("run", horizontalInput!=0);
        animate.SetBool("ground",Ground);
    }
    private void Jumping()
    {
        body.velocity=new Vector2(body.velocity.x, jumpForce);
        animate.SetTrigger("jump");
        Ground=false;
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag=="Ground")
        {
            Ground=true;
        }
    }
    private void FlipPlayer()
    {
        Vector3 currentScale=gameObject.transform.localScale;
        currentScale.x*=-1;
        gameObject.transform.localScale=currentScale;
        isRight=!isRight;
    }
    public bool canShoot()
    {
        return horizontalInput != 0;
    }
}
