using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class EnemyCollide : MonoBehaviour
{
    public HealthManager healthManager;
    private Animator animate;
    void Awake()
    {
        animate=GetComponent<Animator>();
    }
    private void OnTriggerEnter2D(Collider2D collider)
    {
        if(collider.transform.tag=="Enemy")
        {
            healthManager.health--;
            if(healthManager.health <= 0)
            {
                gameObject.SetActive(false);
                SceneManager.LoadScene("GameEnd");
            }
            else
            {
                StartCoroutine(Hurt());
            }
        }
    }
    IEnumerator Hurt()
    {
        animate.SetTrigger("hurt");
        yield return new WaitForSeconds(0);
    }
}
