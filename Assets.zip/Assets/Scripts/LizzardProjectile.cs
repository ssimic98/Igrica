using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
public class LizzardProjectile : MonoBehaviour
{
    public float fireballSpeed;
    public float resetTime;
    public HealthManager healthManager;
    public Animator playerAnimate;
    private float fireballLifetime;
    private Animator fireballAnimate;
    private BoxCollider2D boxCollider;

    private bool hit;

    private void Awake()
    {
        fireballAnimate = GetComponent<Animator>();
        boxCollider = GetComponent<BoxCollider2D>();
    }

    public void ActivateProjectile()
    {
        hit = false;
        fireballLifetime = 0;
        gameObject.SetActive(true);
        boxCollider.enabled = true;
    }
    private void Update()
    {
        if (hit) return;
        float movementSpeed = fireballSpeed * Time.deltaTime;
        transform.Translate(-movementSpeed, 0, 0);
        
        fireballLifetime += Time.deltaTime;
        if (fireballLifetime > resetTime)
            gameObject.SetActive(false);
    }

    private void OnTriggerEnter2D(Collider2D collider)
    {
        hit = true;
        boxCollider.enabled = false;

        if (fireballAnimate != null)
            fireballAnimate.SetTrigger("explode"); 
        else
            gameObject.SetActive(false); 
        if(collider.transform.tag=="Player")
        {
            fireballAnimate.SetTrigger("explode");
            healthManager.health--;
            if(healthManager.health <= 0)
            {
                gameObject.SetActive(false);
                SceneManager.LoadScene("GameEnd");
            }
            else
            {
                StartCoroutine(Hurt());
            }
        }
    }
    IEnumerator Hurt()
    {
        playerAnimate.SetTrigger("hurt");
        yield return new WaitForSeconds(0);
    }
    private void Deactivate()
    {
        gameObject.SetActive(false);
    }
}