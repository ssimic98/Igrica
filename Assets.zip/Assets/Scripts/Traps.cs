using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Traps : MonoBehaviour
{
     public HealthManager healthManager;
    private Animator animate;
    private BoxCollider2D boxCollider;
    void Awake()
    {
        animate=GetComponent<Animator>();
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.transform.tag=="Traps")
        {
            healthManager.health--;
            if(healthManager.health <= 0)
            {
                gameObject.SetActive(false);
                SceneManager.LoadScene("GameEnd");
            }
            else
            {
                StartCoroutine(Hurt());
            }
        }
    }
    IEnumerator Hurt()
    {
        animate.SetTrigger("hurt");
        yield return new WaitForSeconds(0);
    }
}
